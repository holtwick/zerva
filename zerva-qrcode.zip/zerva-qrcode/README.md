# 🌱 Zerva useQrCode

**This is a side project of [Zerva](https://github.com/holtwick/zerva)**

> Show QR Code in the console for external IP addresses, to simplify debugging for mobile development.