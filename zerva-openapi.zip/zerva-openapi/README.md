# 🌱 Zerva useOpenApi

**This is a side project of [Zerva](https://github.com/holtwick/zerva)**

> Supporting OpenAPi docs
