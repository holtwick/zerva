declare module '*.yaml' {
  const value: unknown // Add type definitions here if desired
  export default value
}
